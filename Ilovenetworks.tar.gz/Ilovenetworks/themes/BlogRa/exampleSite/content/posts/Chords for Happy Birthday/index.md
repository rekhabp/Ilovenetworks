---
title: Chords for Happy Birthday
date: 2020-12-23
tags: [music, chords]
image: hbd.png
---

{{<highlight md>}}
      C           G
Happy birthday to you

      G           C
Happy birthday to you

      C             F
Happy birthday dear BlogRa

      C        Bdim C
Happy birthday to   you
{{</highlight>}}
