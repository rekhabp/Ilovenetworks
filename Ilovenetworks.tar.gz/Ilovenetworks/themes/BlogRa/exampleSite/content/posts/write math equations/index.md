---
title: Write Math Equations
date: 2020-12-21
tags: [math]
math: true
image: equation.jpg
---

Write math equations with ease. At first enable **math:true** in front matter.

Then write this-

{{<highlight md>}}
$$ \varphi = \dfrac{1+\sqrt5}{2}= 1.6180339887… $$
{{</highlight>}}

to produce this-

$$ \varphi = \dfrac{1+\sqrt5}{2}= 1.6180339887… $$

And write this-

{{<highlight md>}}
$$
 \varphi = 1+\frac{1} {1+\frac{1} {1+\frac{1} {1+\cdots} } } 
$$
{{</highlight>}}

to produce this-

$$
 \varphi = 1+\frac{1} {1+\frac{1} {1+\frac{1} {1+\cdots} } } 
$$