---
title: "DevRa"
subtitle: "The Practical Software Engineering Blog"
date: 2020-03-25T04:52:30+06:00
draft: false
---

<!-- You can add a short description if you want -->