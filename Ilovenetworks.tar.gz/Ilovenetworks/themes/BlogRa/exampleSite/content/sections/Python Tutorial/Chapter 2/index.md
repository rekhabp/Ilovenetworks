---
title: Chapter 2
date: 2020-12-02
tags: ["python"]
---

This is Chapter 2.